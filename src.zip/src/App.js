import React from 'react'

import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './Style.css'
import Dashboard from './Dashboard'
import Test from './Test'
import Login from './Login'

import '../node_modules/bootstrap/dist/css/bootstrap.css'
import Signup from './Signup'

function App() {
  return (
    <div>
   {/* <Dashboard/>  */}
   <BrowserRouter>
   <Routes>

    <Route path='/' element={<Login/>}/>
    <Route path='/signup' element={<Signup/>}/>
    <Route path='/dashboard/:id' element={<Dashboard/>}/>
    <Route path='/test' element={<Test/>}/>
   </Routes>
   </BrowserRouter>
    </div>
  )
}

export default App
