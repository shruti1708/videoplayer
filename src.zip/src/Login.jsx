import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

const Login = () => {
  const [state, setstate] = useState({
    Username: '',
    Password: ''
  })

  const navigate = useNavigate()

  function set(e) {
    setstate({ ...state, [e.target.name]: e.target.value })
  }

  async function login(e) {
    e.preventDefault();
    const ack = await fetch('http://localhost:3010/get_user', {
      method: 'post',
      body: JSON.stringify(state),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const user = await ack.json()
    console.log(user[0])
    if (user[0]) {
     navigate(`/dashboard/${user[0]._id}`)
    }else{
      alert('Wrong User Credential')
    }
  }

  return (
    <div>
      <div className='login'>
        <div>
          <h1 className='heading_login'>Login</h1>
          <form className='form'>
            <label>UserName:</label>
            <input type="text" name='Username' onChange={set} placeholder='Enter your UserName' className='form-control' />
            <label>Password:</label>
            <input type="password" name='Password' onChange={set} placeholder='Enter your password' className='form-control' />
            <div style={{ textAlign: 'center' }}>
              <button className='btn btn-primary mt-2' onClick={login}>Login</button>
              <div><Link to={'/signup'}>Create Account</Link></div>
            </div>
          </form>
        </div>

      </div>
      <div className='footer'>Made by: Shruti Bhimrajka</div>
    </div>
  )
}

export default Login
