import React, { useEffect, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'

function Dashboard() {

  const param = useParams()
  const [widths, set_widths] = useState()
  const [total, set_total] = useState()

  const titles = useRef()
  const disc = useRef()
  const video_tag_data = useRef()

  const [vid_index, set_vid_index] = useState()

  const [videos, setvideos] = useState([])
  const [video_watched, set_video_watched] = useState()

  async function get_user() {
    const user_data = await fetch("http://localhost:3010/get_user_data", {
      method: 'post',
      body: JSON.stringify(param),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const userdata1 = await user_data.json()
    set_video_watched(userdata1[0].Video_Viewed)
  }
  useEffect(function () {
    get_user()
  }, [])

  useEffect(function () {
    const ind = videos.length
    console.log(ind)
    const wid = (video_watched / ind) * 100
    set_widths(wid)
  }, [videos.length])

  async function get_videos() {
    const videos = await fetch("http://localhost:3010/get_video")
    const vid = await videos.json()
    setvideos(vid)
  }

  useEffect(function () {
    get_videos()
  }, [])

  function load(index) {
    titles.current.innerHTML = videos[index].title
    disc.current.innerHTML = videos[index].discription
    video_tag_data.current.src = videos[index].video
    set_vid_index(index)
  }

  async function unlock_next() {
    await fetch('http://localhost:3010/update_user_data', {
      method: 'put',
      body: JSON.stringify({ "id": param.id, "index_vid": vid_index + 1 }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
  }

  function check_videowatch_percentage() {
    const vid = video_tag_data.current
    const watch_time = (vid.currentTime / vid.duration) * 100
    if (watch_time >= 90) {
      unlock_next()
    }
  }

  return (
    <div>
      <div className='header'>
        <div><span>Videos Watched: </span>{video_watched}/{videos.length}</div>
        <div className='progress'>
          <div style={{ height: '100%', width: `${widths}%`, backgroundColor: 'green' }} className='text-center'>{widths ? widths.toFixed(2) : ''}%</div>
        </div>
        <Link to={'/'} className='btn btn-danger'>LogOut</Link>
      </div>
      <div className='dashboard'>
        <div>
          <div className='videos_heading'>Videos</div>
          {
            videos.map(function (video, index) {
              if (video_watched >= index) {
                return (
                  <div className='video video_1' onClick={() => load(index)} key={index}>
                    <img src="./Image/video-icon.png" alt="" />
                    <span>{video.title}</span>
                  </div>
                )
              } else {
                return (
                  <div className='video video_2' key={index}>
                    <img src="./Image/video-icon.png" alt="" />
                    <span>{video.title}</span>
                  </div>
                )
              }
            })
          }
        </div>
        <div className='video_pannel'>
          <div className='play_video'>
            <h1 className='title_video' ref={titles}>Title</h1>
            <video ref={video_tag_data} controls className='video_tag' src="" onTimeUpdate={check_videowatch_percentage} onContextMenu={(e) => e.preventDefault()}></video>
          </div>
          <div className='discription'>
            <div className='videos_heading'>Discription</div>
            <div className='discription_details' ref={disc}>No Discription</div>
          </div>
        </div>

      </div>
      <div className='footer'>Made by: Shruti Bhimrajka</div>

    </div>
  )
}

export default Dashboard