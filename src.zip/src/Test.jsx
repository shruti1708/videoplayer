import React, { useRef, useState } from 'react'

function Test() {
    const image = useRef()
    const [data,setdata] = useState()

    function load() {
        const img = image.current.files[0]
        const read = new FileReader()
        if (img !== undefined) {
            read.readAsDataURL(img)
            read.onload = function () {
                setdata({ ...data, 'logo': read.result })
            }
        }
    }

    function save() {
        fetch('http://localhost:3010/Insert', {
            method: 'post',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json'
            }

        })
    }

    return (
        <div >
            <input name='file' type="file" ref={image} onChange={load} />
            <button onClick={save}>Save</button>
        </div>
    )
}

export default Test