import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

const Signup = () => {
    const [state, setstate] = useState({
        Name: '',
        Phone: '',
        Email: '',
        Username: '',
        Password: '',
        Video_Viewed:'0'
    })

    const navigate = useNavigate()

    function set(e) {
        setstate({ ...state, [e.target.name]: e.target.value })
    }

    async function signup(e) {
        e.preventDefault();
        if (state.Name == '' || state.Phone == '' || state.Email == '' || state.Username == '' || state.Password == '') {
            alert('Fields are empty')
        } else {
            const ack = await fetch('http://localhost:3010/account_create', {
                method: 'post',
                body: JSON.stringify(state),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            if (ack.status === 200) {
                alert("account created")
                navigate('/')
            } else {
                alert('Some Error occured Please Try Again')
            }
        }
    }
    return (
        <div>
            <div className='login'>
                <div>
                    <h1 className='heading_login'>SignUp</h1>
                    <form className='form'>
                        <label>Name:</label>
                        <input type="text" name='Name' onChange={set} placeholder='Enter your Name' className='form-control' />
                        <label>Phone:</label>
                        <input type="number" name='Phone' onChange={set} placeholder='Enter your Phone Number' className='form-control' />
                        <label>E-mail:</label>
                        <input type="text" name='Email' onChange={set} placeholder='Enter your E-mail' className='form-control' />
                        <label>UserName:</label>
                        <input type="text" name='Username' onChange={set} placeholder='Enter your UserName' className='form-control' />
                        <label>Password:</label>
                        <input type="password" name='Password' onChange={set} placeholder='Enter your password' className='form-control' />
                        <div style={{ textAlign: 'center' }}>
                            <button className='btn btn-primary mt-2' onClick={signup}>SignUp</button>
                            <div><Link to={'/'}>Login</Link></div>
                        </div>
                    </form>
                </div>
            </div>
            <div className='footer'>Made by: Shruti Bhimrajka</div>
        </div>

    )
}

export default Signup
